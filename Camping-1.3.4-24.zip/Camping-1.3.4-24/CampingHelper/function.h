//
//  function.h
//  CampingHelper
//
//  Created by Han Sohn on 12-3-6.
//  Copyright (c) 2012年 Han.zh. All rights reserved.
//

#ifndef CampingHelper_function_h

#ifndef _WIN32
#include <sys/select.h>
#endif
#include <stdio.h>

unsigned long Sys_GetTime();

#define CampingHelper_function_h
#endif
